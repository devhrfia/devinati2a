<?php

namespace App\Filament\Resources;

use Filament\Forms;
use Filament\Tables;
use App\Models\ScienceAndTech;
use Filament\Resources\Form;
use Filament\Resources\Table;
use Filament\Resources\Resource;
use Filament\Forms\Components\Card;
use Filament\Tables\Columns\TextColumn;
use Filament\Forms\Components\TextInput;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Database\Eloquent\SoftDeletingScope;
use App\Filament\Resources\ScienceAndTechResource\Pages;
use App\Filament\Resources\ScienceAndTechResource\RelationManagers;

class ScienceAndTechResource extends Resource
{
    protected static ?string $model = ScienceAndTech::class;

    protected static ?string $navigationIcon = 'heroicon-o-collection';

    public static function form(Form $form): Form
    {
        return $form
            ->schema([
                Card::make()
                    ->schema([
                        TextInput::make('Materi')->required(),
                        TextInput::make('Penjelasan')->required(),
                    ])
            ]);
    }

    public static function table(Table $table): Table
    {
        return $table
            ->columns([
                TextColumn::make('Materi')->sortable()->searchable(),
                TextColumn::make('Penjelasan'),
            ])
            ->filters([
                //
            ])
            ->actions([
                Tables\Actions\EditAction::make(),
                Tables\Actions\DeleteAction::make(),
            ])
            ->bulkActions([
                Tables\Actions\DeleteBulkAction::make(),
            ]);
    }
    
    public static function getRelations(): array
    {
        return [
            //
        ];
    }
    
    public static function getPages(): array
    {
        return [
            'index' => Pages\ListScienceAndTeches::route('/'),
            'create' => Pages\CreateScienceAndTech::route('/create'),
            'edit' => Pages\EditScienceAndTech::route('/{record}/edit'),
        ];
    }    
}
