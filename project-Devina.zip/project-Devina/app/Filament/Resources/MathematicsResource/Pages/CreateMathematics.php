<?php

namespace App\Filament\Resources\MathematicsResource\Pages;

use App\Filament\Resources\MathematicsResource;
use Filament\Pages\Actions;
use Filament\Resources\Pages\CreateRecord;

class CreateMathematics extends CreateRecord
{
    protected static string $resource = MathematicsResource::class;
}
