<?php

namespace App\Filament\Resources\MathematicsResource\Pages;

use App\Filament\Resources\MathematicsResource;
use Filament\Pages\Actions;
use Filament\Resources\Pages\ListRecords;

class ListMathematics extends ListRecords
{
    protected static string $resource = MathematicsResource::class;

    protected function getActions(): array
    {
        return [
            Actions\CreateAction::make(),
        ];
    }
}
