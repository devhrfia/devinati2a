<?php

namespace App\Filament\Resources\SocietynCultureResource\Pages;

use App\Filament\Resources\SocietynCultureResource;
use Filament\Pages\Actions;
use Filament\Resources\Pages\CreateRecord;

class CreateSocietynCulture extends CreateRecord
{
    protected static string $resource = SocietynCultureResource::class;
}
