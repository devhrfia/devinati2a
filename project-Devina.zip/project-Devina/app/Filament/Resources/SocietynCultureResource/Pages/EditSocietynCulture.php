<?php

namespace App\Filament\Resources\SocietynCultureResource\Pages;

use App\Filament\Resources\SocietynCultureResource;
use Filament\Pages\Actions;
use Filament\Resources\Pages\EditRecord;

class EditSocietynCulture extends EditRecord
{
    protected static string $resource = SocietynCultureResource::class;

    protected function getActions(): array
    {
        return [
            Actions\DeleteAction::make(),
        ];
    }
}
