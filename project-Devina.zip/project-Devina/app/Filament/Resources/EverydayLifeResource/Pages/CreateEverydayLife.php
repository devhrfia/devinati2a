<?php

namespace App\Filament\Resources\EverydayLifeResource\Pages;

use App\Filament\Resources\EverydayLifeResource;
use Filament\Pages\Actions;
use Filament\Resources\Pages\CreateRecord;

class CreateEverydayLife extends CreateRecord
{
    protected static string $resource = EverydayLifeResource::class;
}
