<?php

namespace App\Filament\Resources\EverydayLifeResource\Pages;

use App\Filament\Resources\EverydayLifeResource;
use Filament\Pages\Actions;
use Filament\Resources\Pages\EditRecord;

class EditEverydayLife extends EditRecord
{
    protected static string $resource = EverydayLifeResource::class;

    protected function getActions(): array
    {
        return [
            Actions\DeleteAction::make(),
        ];
    }
}
