<?php

namespace App\Filament\Resources\ScienceAndTechResource\Pages;

use App\Filament\Resources\ScienceAndTechResource;
use Filament\Pages\Actions;
use Filament\Resources\Pages\CreateRecord;

class CreateScienceAndTech extends CreateRecord
{
    protected static string $resource = ScienceAndTechResource::class;
}
