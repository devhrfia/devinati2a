<?php

namespace App\Filament\Resources\ScienceAndTechResource\Pages;

use App\Filament\Resources\ScienceAndTechResource;
use Filament\Pages\Actions;
use Filament\Resources\Pages\ListRecords;

class ListScienceAndTeches extends ListRecords
{
    protected static string $resource = ScienceAndTechResource::class;

    protected function getActions(): array
    {
        return [
            Actions\CreateAction::make(),
        ];
    }
}
