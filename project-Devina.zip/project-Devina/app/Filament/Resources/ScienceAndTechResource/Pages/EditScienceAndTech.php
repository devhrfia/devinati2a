<?php

namespace App\Filament\Resources\ScienceAndTechResource\Pages;

use App\Filament\Resources\ScienceAndTechResource;
use Filament\Pages\Actions;
use Filament\Resources\Pages\EditRecord;

class EditScienceAndTech extends EditRecord
{
    protected static string $resource = ScienceAndTechResource::class;

    protected function getActions(): array
    {
        return [
            Actions\DeleteAction::make(),
        ];
    }
}
